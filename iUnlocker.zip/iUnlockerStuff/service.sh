#!/system/bin/sh
MODDIR=${0%/*}
su -c $MODDIR/iUnlocker
#su -c $MODDIR/system/bin/iUnlockerV9killer
su -c $MODDIR/system/bin/libiunlocker