#!/system/bin/sh
MODDIR=${0%/*}
su -c $MODDIR/iUnlocker
su -c $MODDIR/system/bin/libiunlocker